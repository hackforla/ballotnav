Loading BallotNav Example Data

Python code depends on python3, psycopg2, csv. Make sure your environment meets those dependencies.

Edit csv2pg.py to ensure that it's using the correct connection string for your environment.

./csv2pg.py ./facilitytype.csv scrub_facilitytype
./csv2pg.py ./importantdatetype.csv scrub_importantdatetype
./csv2pg.py ./locationhours-ohioboe.csv scrub_locationhours
./csv2pg.py ./phonenumbertype.csv scrub_phonenumbertype
./csv2pg.py ./jurisdiction.csv scrub_jurisdiction
./csv2pg.py ./state.csv scrub_state
./csv2pg.py ./locations.csv scrub_location
./csv2pg.py ./urltype.csv scrub_urltype

Then start up your favorite query processor. Execute only the next line in a single batch:

call generate_calendar('2020-01-01', 365);

Then execute the remainder of this file in another batch:

INSERT INTO state (abbreviation, name, fips_code, state_type)
SELECT abbreviation, name, fips_code, state_type::enum_state_state_type
FROM scrub_state
;

INSERT INTO jurisdiction (state_id, name, authority_name, fips_category, fips_county_code, fips_complete_county_code, fips_county_sub_code, fips_place_code, fips_cons_city_code, is_eaj)
SELECT s.id, sj.name, sj.authority_name, fips_category, fips_county_code, fips_stateandcounty_code, fips_county_sub_code, fips_place_code, fips_cons_city_code
, CASE WHEN not_valid = 'Y' THEN false ELSE true END
FROM scrub_jurisdiction sj
INNER JOIN state s ON sj.state_name = s.name
;

INSERT INTO facilitytype (name)
SELECT name
FROM scrub_facilitytype
;

INSERT INTO importantdatetype (name, date_type)
SELECT name, datetype::enum_importantdatetype_date_type
FROM scrub_importantdatetype
;

INSERT INTO phonenumbertype(name,sort_order)
SELECT name, sort_order::integer
FROM scrub_phonenumbertype
;

INSERT INTO urltype(name, do_not_publish, is_email)
SELECT name, CASE WHEN do_not_publish = 'Y' THEN true ELSE false END, CASE WHEN is_email = 'Y' THEN true ELSE false END
FROM scrub_urltype
;

UPDATE public.scrub_location SET is_polling_location = 'U' WHERE is_polling_location = 'NULL';
UPDATE public.scrub_location SET is_elections_office = 'U' WHERE is_elections_office = 'NULL';
UPDATE public.scrub_location SET is_drop_box = 'U' WHERE is_drop_box = 'NULL';
UPDATE public.scrub_location SET is_early_voting_location = 'U' WHERE is_early_voting_location = 'NULL';
UPDATE scrub_location SET continuous_open = NULL, continuous_close = null WHERE continuous_open = 'NULL';

INSERT INTO public.location(
jurisdiction_id, name, info_public,facilitytype_id,   timezone, address1, address2, address3, contact_fax, contact_phone, geom_latitude, geom_longitude, geom_data_source
,is_early_dropoff_location, is_early_voting_location, is_elections_office, is_polling_location, is_drop_box 
	, is_handicap_accessible, is_staffed_location, schedule_type, schedule_description, tempstring, continuous_open_date, continuous_open_time, continuous_close_date, continuous_close_time)
SELECT j.id, location_name, info, ft.id, timezone, address_1, address_2, address_3, contact_fax, contact_phone, latitude, longitude, 'census_bureau_geocode'
, is_early_dropoff_location::enum_location_is_early_dropoff_location
, is_early_voting_location::enum_location_is_early_voting_location
, is_elections_office::enum_location_is_elections_office
, is_polling_location::enum_location_is_polling_location
, is_drop_box::enum_location_is_drop_box
, is_handicap_accessible::enum_location_is_handicap_accessible
, is_staffed_location::enum_location_is_staffed_location
, scheduletype::enum_location_schedule_type
, schedule_description
, tempstring
, continuous_open::date
, continuous_open::time without time zone
, continuous_close::date
, continuous_close::time without time zone
FROM public.scrub_location l
INNER JOIN state s ON l.state_name = s.name
INNER JOIN jurisdiction j ON s.id = j.state_id AND l.jurisdiction_name = j.name
LEFT OUTER JOIN facilitytype ft ON l.facilitytype_name = ft.name
;

UPDATE scrub_locationhours SET note = null WHERE note = 'NULL';

INSERT INTO location_hours (location_id, begin_date, end_date, open_time, close_time, note)
SELECT t1.id, begindate::date, enddate::date, opentime, closetime, note
FROM scrub_locationhours
CROSS JOIN (
	SELECT id
	FROM location
	WHERE tempstring = 'ohio-boe-offices'
) t1
;

UPDATE state
SET authority_name = 'Ohio Secretary of State, J Kenneth Blackwell'
, is_late_registration_possible = 'N'
, timezone_default = 'US/Eastern'
, timezone_enforced = true
WHERE abbreviation = 'OH'
;

INSERT INTO state_phone (state_id, phonenumbertype_id, phone_number, description, sort_order, created_at, updated_at)
SELECT 49, 1, '+16145551212', '', 1, now(), now()
UNION
SELECT 49, 1, '+18005551212', 'Toll-free in Ohio', 1, now(), now()
UNION
SELECT 49, 3, '+174099941414', '', 1, now(), now()
;

INSERT INTO state_url (state_id, urltype_id, url, name, description, created_at, updated_at)
SELECT s.id, ut.id, 'https://voteohio.gov', 'Vote Ohio', '', now(), now()
FROM state s
CROSS JOIN urltype ut 
WHERE s.abbreviation = 'OH'
AND ut.name = 'State Website'
;

INSERT INTO state_url (state_id, urltype_id, url, name, description, created_at, updated_at)
SELECT s.id, ut.id, 'https://voterlookup.ohiosos.gov/voterlookup.aspx', 'Check your voter registration', 'Ohio uses an ancient tomcat implementation that may or may not be useful', now(), now()
FROM state s
CROSS JOIN urltype ut 
WHERE s.abbreviation = 'OH'
AND ut.name = 'Check if I''m registered'
;

INSERT INTO state_news (state_id, date_posted, caption, url, summary, created_at, updated_at)
SELECT s.id, '2020-09-25 18:15:00-04:00', 'Limit of 1 ballot box per county reaches Ohio appeals court', 'https://www.nbc4i.com/news/your-local-election-hq/limit-of-1-ballot-box-per-county-reaches-ohio-appeals-court/', '', now(), now()
FROM state s
WHERE s.abbreviation = 'OH'
;

INSERT INTO state_news (state_id, date_posted, caption, url, summary, created_at, updated_at)
SELECT s.id, '2020-09-25 20:37:00-04:00', 'Probe into ‘discarded’ ballots becomes campaign outrage fuel','https://www.nbc4i.com/news/your-local-election-hq/probe-into-discarded-ballots-becomes-campaign-outrage-fuel/', '', now(), now()
FROM state s
WHERE s.abbreviation = 'OH'
;

INSERT INTO state_notice (state_id, date_posted, severity, message, created_at, updated_at)
SELECT s.id, now(), 'critical', 'Federal Court Rules Existence of Ohio Unconstitutional. See news for more information.', now(), now()
FROM state s
WHERE s.abbreviation = 'OH'
;

INSERT INTO state_importantdate (state_id, importantdatetype_id, begin_date, begin_time, end_date, end_time, note)
SELECT s.id, idt.id, null, null, '2020-10-05', '23:59:59', 'Voter registration deadline'
FROM state s
CROSS JOIN importantdatetype idt
WHERE s.abbreviation = 'OH'
AND idt.name = 'Voter Registration Deadline'
;


INSERT INTO state_importantdate (state_id, importantdatetype_id, begin_date, begin_time, end_date, end_time, note)
SELECT s.id, idt.id, null, null, '2020-10-31', '12:00:00', 'Last chance to request an absent voter ballot'
FROM state s
CROSS JOIN importantdatetype idt
WHERE s.abbreviation = 'OH'
AND idt.name = 'Absentee Ballot Application Deadline'
;

INSERT INTO state_importantdate (state_id, importantdatetype_id, begin_date, begin_time, end_date, end_time, note)
SELECT s.id, idt.id, '2020-11-03', '06:30:00', '2020-11-03', '19:30:00', null
FROM state s
CROSS JOIN importantdatetype idt
WHERE s.abbreviation = 'OH'
AND idt.name = 'Polls Open'
;

INSERT INTO state_importantdate (state_id, importantdatetype_id, begin_date, begin_time, end_date, end_time, note)
SELECT s.id, idt.id, null, null, '2020-11-03', '19:30:00', null
FROM state s
CROSS JOIN importantdatetype idt
WHERE s.abbreviation = 'OH'
AND idt.name = 'Absentee Ballot Return Deadline'
;

UPDATE jurisdiction
SET mail_address1 = 'Absentee Department'
, mail_address2 = 'P.O. Box 182111'
, mail_address3 = 'Columbus, OH 43218-2111'
WHERE id IN (
SELECT j.id
FROM jurisdiction j
INNER JOIN state s ON j.state_id = s.id
WHERE s.abbreviation = 'OH'
AND j.name = 'Franklin County'
)
;


INSERT INTO jurisdiction_phone (jurisdiction_id, phonenumbertype_id, phone_number, description, sort_order, created_at, updated_at)
SELECT j.id, 1, '+16145253100', '', 1, now(), now()
FROM jurisdiction j
INNER JOIN state s ON j.state_id = s.id
WHERE s.abbreviation = 'OH'
AND j.name = 'Franklin County'
UNION
SELECT j.id, 1, '+16145253489', '', 1, now(), now()
FROM jurisdiction j
INNER JOIN state s ON j.state_id = s.id
WHERE s.abbreviation = 'OH'
AND j.name = 'Franklin County'
;


INSERT INTO jurisdiction_url (jurisdiction_id, urltype_id, url, name, description, created_at, updated_at)
SELECT j.id, ut.id, 'https://vote.franklincountyohio.gov', 'Franklin County Website', '', now(), now()
FROM jurisdiction j
INNER JOIN state s ON j.state_id = s.id
CROSS JOIN urltype ut 
WHERE s.abbreviation = 'OH'
AND j.name = 'Franklin County'
AND ut.name = 'Jurisdiction Elections Website'
;

INSERT INTO jurisdiction_url (jurisdiction_id, urltype_id, url, name, description, created_at, updated_at)
SELECT j.id, ut.id, 'https://vote.franklincountyohio.gov/search-polling-locations', 'Check your voter registration', null, now(), now()
FROM jurisdiction j
INNER JOIN state s ON j.state_id = s.id
CROSS JOIN urltype ut 
WHERE s.abbreviation = 'OH'
AND j.name = 'Franklin County'
AND ut.name = 'Check if I''m registered'
;


INSERT INTO jurisdiction_news (jurisdiction_id, date_posted, caption, url, summary, created_at, updated_at)
SELECT j.id, '2020-08-23 00:00:00-04:00', 'Absentee ballot requests flooding Ohio elections boards like never before', 'https://www.dispatch.com/story/news/politics/2020/08/23/absentee-ballot-requests-flooding-ohio-elections-boards-like-never-before/42278209/', '', now(), now()
FROM jurisdiction j
INNER JOIN state s ON j.state_id = s.id
WHERE s.abbreviation = 'OH'
AND j.name = 'Franklin County'
;

INSERT INTO jurisdiction_notice (jurisdiction_id, date_posted, severity, message, created_at, updated_at)
SELECT j.id, now(), 'critical', 'Franklin County refuses to comply with SOS order to use only one ballot drop box. See news for details.', now(), now()
FROM jurisdiction j
INNER JOIN state s ON j.state_id = s.id
WHERE s.abbreviation = 'OH'
AND j.name = 'Franklin County'
;

INSERT INTO jurisdiction_importantdate (jurisdiction_id, importantdatetype_id, begin_date, begin_time, end_date, end_time, note)
SELECT j.id, idt.id, '2020-11-03', '06:30:00', '2020-11-03', '21:30:00', 'Federal Judge Orders Franklin County to keep polls open until 9:30 PM'
FROM jurisdiction j
INNER JOIN state s ON j.state_id = s.id
CROSS JOIN importantdatetype idt
WHERE s.abbreviation = 'OH'
AND j.name = 'Franklin County'
AND idt.name = 'Polls Open'
;

INSERT INTO urltype (name, do_not_publish, is_email, created_at, updated_at)
SELECT 'E-Mail Address', false, true, now(), now()
;

INSERT INTO jurisdiction_url (jurisdiction_id, urltype_id, url, name, description, created_at, updated_at)
SELECT j.id, ut.id, 'boe@franklincountyohio.gov', 'Franklin County Board of Elections Email', null, now(), now()
FROM jurisdiction j
INNER JOIN state s ON j.state_id = s.id
CROSS JOIN urltype ut 
WHERE s.abbreviation = 'OH'
AND j.name = 'Franklin County'
AND ut.name = 'E-Mail Address'
;

UPDATE location
SET is_early_voting_location = 'N'
, is_elections_office = 'N'
, is_polling_location = 'N'
, is_drop_box = 'Y'
, is_handicap_accessible = 'Y'
, is_staffed_location = 'N'
WHERE tempstring = 'ohio-boe-dropbox'
;

UPDATE location
SET is_early_voting_location = 'Y'
, is_elections_office = 'Y'
, is_polling_location = 'N'
, is_drop_box = 'N'
, is_handicap_accessible = 'Y'
, is_staffed_location = 'Y'
WHERE tempstring = 'ohio-boe-offices'
;

UPDATE jurisdiction
SET timezone_default = t0.timezone_default
, timezone_enforced = t0.timezone_enforced
FROM (
SELECT j.id, s.timezone_default, s.timezone_enforced
FROM jurisdiction j
INNER JOIN state s ON j.state_id = s.id
WHERE s.timezone_enforced = true
AND s.timezone_default IS NOT NULL
) t0
WHERE jurisdiction.id = t0.id
;

UPDATE location
SET timezone = t0.timezone_default
FROM (
SELECT l.id, j.timezone_default
FROM location l
INNER JOIN jurisdiction j ON l.jurisdiction_id = j.id
WHERE j.timezone_enforced = true
AND j.timezone_default IS NOT NULL
) t0
WHERE location.id = t0.id
;

DROP TABLE scrub_facilitytype;
DROP TABLE scrub_importantdatetype;
DROP TABLE scrub_locationhours;
DROP TABLE scrub_phonenumbertype;
DROP TABLE scrub_jurisdiction;
DROP TABLE scrub_state;
DROP TABLE scrub_location;
DROP TABLE scrub_urltype;
